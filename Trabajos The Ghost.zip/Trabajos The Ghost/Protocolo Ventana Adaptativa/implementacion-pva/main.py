import secrets
import socket
import struct
import time
from pathlib import Path

from protocolo import (
    ABRIR, APERTURA_CONFIRMADA, DATOS, CONFIRMAR, CERRAR, CIERRE_CONFIRMADO,
    crear_paquete, leer_paquete, dividir_mensaje, reconstruir_mensaje,
)


def esperar_confirmacion(conexion, destino, sesion, tipo, confirmado=0, maximo=None):
    if maximo is None:
        maximo = confirmado
    limite = time.monotonic() + 2
    while True:
        restante = limite - time.monotonic()
        if restante <= 0:
            raise TimeoutError("No llegó la confirmación en 2 segundos.")
        conexion.settimeout(restante)
        datos, origen = conexion.recvfrom(65535)
        if origen != destino:
            continue
        try:
            paquete = leer_paquete(datos)
        except ValueError:
            continue
        if (paquete["sesion"] == sesion and paquete["tipo"] == tipo
                and confirmado <= paquete["confirmado"] <= maximo):
            return paquete["confirmado"]


def recibir(puerto):
    partes = []
    sesion = origen_sesion = None
    limite = None
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as conexion:
        conexion.bind(("0.0.0.0", puerto))
        print(f"Espero un mensaje en el puerto {puerto}...", flush=True)
        while True:
            if limite is not None:
                restante = limite - time.monotonic()
                if restante <= 0:
                    raise TimeoutError("Sesión incompleta: sin progreso durante 12 segundos.")
                conexion.settimeout(restante)
            datos, origen = conexion.recvfrom(65535)
            try:
                paquete = leer_paquete(datos)
            except ValueError as error:
                print(f"Descarto paquete: {error}", flush=True)
                continue
            tipo = paquete["tipo"]
            if sesion is None:
                if tipo != ABRIR:
                    continue
                apertura = paquete["carga"]
                total_bytes, total_partes = struct.unpack("!II", apertura)
                sesion, origen_sesion = paquete["sesion"], origen
                limite = time.monotonic() + 12
                print(f"OPEN: sesión {sesion}, {total_partes} partes, {total_bytes} bytes.", flush=True)
            if paquete["sesion"] != sesion or origen != origen_sesion:
                continue

            if tipo == ABRIR and paquete["carga"] == apertura:
                respuesta = crear_paquete(APERTURA_CONFIRMADA, sesion)
                print("Respondo OPEN_ACK.", flush=True)
            elif tipo == DATOS:
                numero = paquete["secuencia"]
                longitud = 256 if numero < total_partes - 1 else total_bytes - 256 * (total_partes - 1)
                if numero >= total_partes or len(paquete["carga"]) != longitud:
                    continue
                esperado = len(partes)
                if numero == esperado:
                    partes.append(paquete["carga"])
                    limite = time.monotonic() + 12
                else:
                    print(f"Descarto DATA {numero}: espero {esperado}.", flush=True)
                respuesta = crear_paquete(CONFIRMAR, sesion, confirmado=len(partes))
            elif tipo == CERRAR:
                if len(partes) != total_partes or sum(map(len, partes)) != total_bytes:
                    print("Descarto CLOSE: todavía faltan partes.", flush=True)
                    continue
                texto = reconstruir_mensaje(partes)
                carpeta = Path(__file__).resolve().parent / "recibidos"
                carpeta.mkdir(exist_ok=True)
                archivo = carpeta / f"recibido_{sesion}.txt"
                with archivo.open("xb") as salida:
                    salida.write(b"".join(partes))
                conexion.sendto(crear_paquete(CIERRE_CONFIRMADO, sesion, confirmado=total_partes), origen)
                print(f"CLOSE válido. Respondo CLOSE_ACK.\nMensaje: {texto}\nGuardado: {archivo}", flush=True)
                return
            else:
                continue
            conexion.sendto(respuesta, origen)


def enviar(ip, puerto, texto):
    partes = dividir_mensaje(texto)
    print(f"Divido el mensaje en {len(partes)} partes de hasta 256 bytes; total {sum(map(len, partes))} bytes.", flush=True)
    sesion = secrets.randbelow(2**32 - 1) + 1
    destino = (socket.gethostbyname(ip), puerto)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as conexion:
        carga = struct.pack("!II", sum(map(len, partes)), len(partes))
        conexion.sendto(crear_paquete(ABRIR, sesion, carga=carga), destino)
        esperar_confirmacion(conexion, destino, sesion, APERTURA_CONFIRMADA)
        print(f"OPEN_ACK recibido. Sesión {sesion}, {len(partes)} partes.", flush=True)
        base = 0
        ventana = 2
        esperas_sin_avance = 0
        while base < len(partes):
            fin_bloque = min(base + ventana, len(partes))
            bloque_recuperado = False
            ultimo_enviado = base - 1
            print(f"Inicio bloque {base} a {fin_bloque - 1}. Ventana: {ventana}.", flush=True)
            while base < fin_bloque:
                fin_lote = min(base + ventana, fin_bloque)
                for numero in range(base, fin_lote):
                    conexion.sendto(crear_paquete(DATOS, sesion, secuencia=numero, ventana=ventana, carga=partes[numero]), destino)
                    ultimo_enviado = max(ultimo_enviado, numero)
                while base < fin_lote:
                    try:
                        base = esperar_confirmacion(conexion, destino, sesion, CONFIRMAR, base + 1, ultimo_enviado + 1)
                        esperas_sin_avance = 0
                    except TimeoutError:
                        esperas_sin_avance += 1
                        if esperas_sin_avance == 5:
                            raise TimeoutError("Cinco esperas vencidas sin avance. Envío cancelado.")
                        anterior = ventana
                        ventana = max(2, ventana - 2)
                        bloque_recuperado = True
                        print(f"Sin confirmación. Ventana: {anterior} a {ventana}. Reenvío desde la parte {base}.", flush=True)
                        break
            print(f"Bloque confirmado hasta la parte {fin_bloque - 1}.", flush=True)
            if bloque_recuperado:
                print(f"Bloque recuperado. Mantengo ventana: {ventana}.", flush=True)
            else:
                anterior = ventana
                ventana = min(8, ventana + 2)
                print(f"Bloque limpio. Ventana: {anterior} a {ventana}.", flush=True)
        try:
            conexion.sendto(crear_paquete(CERRAR, sesion, ventana=ventana), destino)
            esperar_confirmacion(conexion, destino, sesion, CIERRE_CONFIRMADO, len(partes))
        except OSError as error:
            raise OSError("Cierre no confirmado; revisa si el receptor guardó el mensaje.") from error
        print(f"CLOSE_ACK recibido. Envío completado. Ventana final: {ventana}.", flush=True)
        print(f"Mensaje enviado: {texto}", flush=True)


def main():
    print("PVA: envío de texto (fase 5, ventana de 2 a 8)")
    print("1. Recibir (iniciar primero)")
    print("2. Enviar")
    print("3. Enviar ejemplo de veinte partes (5120 bytes)")
    opcion = input("Elige 1, 2 o 3: ").strip()
    if opcion not in ("1", "2", "3"):
        print("Elige una opción válida: 1, 2 o 3.")
        return 1
    try:
        puerto = int(input("Puerto [5050]: ").strip() or "5050")
        if not 1 <= puerto <= 65535:
            raise ValueError("El puerto debe estar entre 1 y 65535.")
        if opcion == "1":
            recibir(puerto)
        else:
            ip = input("IP de la PC receptora [127.0.0.1]: ").strip() or "127.0.0.1"
            if opcion == "2":
                texto = input("Mensaje: ")
            else:
                texto = "".join(f"Parte {numero:02d}: ".ljust(256, ".") for numero in range(20))
            enviar(ip, puerto, texto)
    except TimeoutError as error:
        print(f"Venció la espera: {error} Revisa receptor, IP, puerto y conexión.")
        return 1
    except (OSError, ValueError) as error:
        print(f"No se pudo completar la prueba: {error}")
        return 1
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("\nPrueba cancelada.")
        raise SystemExit(1)
